from django.shortcuts import render
from django.http import JsonResponse
import json
from .models import Member,FitnessClass,Attendance

def members_api(request):
    if request.method == 'POST':
        POST = json.loads(request.body)
        member = Member.objects.create(
            first_name=POST["first_name"], 
            last_name =POST["last_name"], 
            email =POST["email"], 
            phone_number =POST["phone_number"], 
            join_date =POST["join_date"] 
        )
        return JsonResponse(member.as_dict())

    return JsonResponse({
        'members': [
            member.as_dict()
            for member in Member.objects.all()
        ]
    })

def member_api(request, member_id):
    try:
        member = Member.objects.get(id=member_id)
    except Member.DoesNotExist:
        return JsonResponse({"error": "Member not found"}, status=404)

    if request.method == 'PUT':
        try:
            data = json.loads(request.body)
            member.first_name = data.get("first_name", member.first_name)
            member.last_name = data.get("last_name", member.last_name)
            member.email = data.get("email", member.email)
            member.phone_number = data.get("phone_number", member.phone_number)
            member.save()
            return JsonResponse(member.as_dict())
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=400)

    if request.method == 'DELETE':
        member.delete()
        return JsonResponse({})
    
    return JsonResponse(member.as_dict())

def fitness_classes_api(request):
    if request.method == 'POST':
        POST = json.loads(request.body)
        fitnessClass = FitnessClass.objects.create(
            name = POST['name'],
            description = POST['description'],
            start_time = POST['start_time'],
            end_time = POST['end_time'],
            instructor = POST['instructor']
        )
        return JsonResponse( fitnessClass.as_dict())

    return JsonResponse({
        'fitnessClass': [
            fitnessClass.as_dict()
            for fitnessClass in FitnessClass.objects.all()
        ]
    })

def fitness_class_api(request, fitness_class_id):
    try:
        fitness_class = FitnessClass.objects.get(id=fitness_class_id)
    except FitnessClass.DoesNotExist:
        return JsonResponse({"error": "Fitness Class not found"}, status=404)

    if request.method == 'PUT':
        try:
            data = json.loads(request.body)
            fitness_class.name = data.get("name", fitness_class.name)
            fitness_class.description = data.get("description", fitness_class.description)
            fitness_class.start_time = data.get("start_time", fitness_class.start_time)
            fitness_class.end_time = data.get("end_time", fitness_class.end_time)
            fitness_class.instructor = data.get("instructor", fitness_class.instructor)
            fitness_class.save()
            return JsonResponse(fitness_class.as_dict())
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=400)

    if request.method == 'DELETE':
        fitness_class.delete()
        return JsonResponse({})
    
    return JsonResponse(fitness_class.as_dict())

def attendances_api(request):
    if request.method == 'POST':
        POST = json.loads(request.body)
        try:
            member = Member.objects.get(id=POST["member_id"])
            fitness_class = FitnessClass.objects.get(id=POST["fitness_class_id"])
            attendance = Attendance.objects.create(
                member=member,
                fitness_class=fitness_class,
                date=POST["date"],
            )
            return JsonResponse( attendance.as_dict())
        
        except Member.DoesNotExist:
            return JsonResponse({"error": "Member not found"}, status=404)
        except FitnessClass.DoesNotExist:
            return JsonResponse({"error": "FitnessClass not found"}, status=404)
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=400)

    return JsonResponse({
        'attendance': [
            attendance.as_dict()
            for attendance in Attendance.objects.all()
        ]
    })

def attendance_api(request,attendance_id):
    try:
        attendance = Attendance.objects.get(id=attendance_id)
    except Attendance.DoesNotExist:
        return JsonResponse({"error": "Attendance not found"}, status=404)
    
    if request.method == 'PUT':
        try:
            data = json.loads(request.body)
            attendance.date= data.get("date", attendance.date)
            return JsonResponse(attendance.as_dict())
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=400)

    if request.method == 'DELETE':
        attendance.delete()
        return JsonResponse({})
    
    return JsonResponse(attendance.as_dict())
    

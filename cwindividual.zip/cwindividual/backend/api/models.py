from django.db import models
from django.urls import reverse

# Model for Gym Members
class Member(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    email = models.EmailField(unique=True)
    phone_number = models.CharField(max_length=15, blank=True, null=True)
    join_date = models.DateField(auto_now_add=True)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"
    
    def as_dict(self):
        return {
            "id": self.id,
            'api': reverse('member api', args=[self.id]),
            "first_name": self.first_name,
            "last_name": self.last_name,
            "email": self.email,
            "phone_number": self.phone_number,
            "join_date": self.join_date.isoformat(),
        }

# Model for Gym Fitness Classes
class FitnessClass(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)
    start_time = models.TimeField()
    end_time = models.TimeField()
    instructor = models.CharField(max_length=100)
    attendees = models.ManyToManyField(Member, through="Attendance")

    def __str__(self):
        return self.name
    
    def as_dict(self):
        return {
            "id": self.id,
            'api': reverse('fitness_class api', args=[self.id]),
            "name": self.name,
            "description": self.description,
            "start_time": self.start_time.strftime("%H:%M:%S"),
            "end_time": self.end_time.strftime("%H:%M:%S"),
            "instructor": self.instructor,
            "attendees": [f"{attendee.first_name} {attendee.last_name}" for attendee in self.attendees.all()],
        }

# Through Model for Attendance Tracking
class Attendance(models.Model):
    member = models.ForeignKey(Member, on_delete=models.CASCADE)
    fitness_class = models.ForeignKey(FitnessClass, on_delete=models.CASCADE)
    date = models.DateField()

    def __str__(self):
        return f"{self.member} attended {self.fitness_class} on {self.date}"
    
    def as_dict(self):
        return {
            "id": self.id,
            'api': reverse('attendance api', args=[self.id]),
            "member": self.member.as_dict(),
            "fitness_class": self.fitness_class.as_dict(),
            "date": self.date.isoformat(),
        }
    
# Create your models here.

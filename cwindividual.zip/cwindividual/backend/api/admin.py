from django.contrib import admin

# Register your models here.
from .models import Member , FitnessClass , Attendance

admin.site.register(Member)
admin.site.register(FitnessClass)
admin.site.register(Attendance)
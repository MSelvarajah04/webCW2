<template>
    <div class="container pt-3">
        <div class="h1 text-center border rounded bg-light p-2 mb-3">
            API Client
        </div>
        <div class="mb-3">
            <u>Response data</u>:             
        </div>
        <pre>{{ response_data }}</pre>

        <!-- Button trigger modal -->
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
        Launch demo modal
        </button>

        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                ...
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button>
            </div>
            </div>
        </div>
        </div>
        <MemberTable
            :members="members"
            @delete-member="deleteMember"
        />
        <FitnessClassTable
            :fitnessClasses="fitnessClasses"
            @delete-fitnessClass="deleteFitnessClass"
        />
    </div>
  </template>
  
<script>
import MemberTable from './components/memberTable.vue';
import FitnessClassTable from './components/fitnessClassTable.vue';


    const baseUrl = 'http://localhost:8000'

    export default {
        components: {
            MemberTable,
            FitnessClassTable
        },

        data() {
            return {
                title: 'Gym members and Fitness Classes',
                members: [],
                fitnessClasses:[],
                newMember: {
                    first_name:'',
                    last_name:'',
                    email:'',
                    phone_number:'',
                    join_data:'',
                },
                newFitnessClass: {
                    name:'',
                    description:'',
                    start_time:'',
                    end_time:'',
                    instructor:'',
                }
            }
        },
        async mounted() {
            const response = await fetch(`${baseUrl}/api/members/`)
            const data = await response.json()
            this.members = data.members;
            const response2 = await fetch(`${baseUrl}/api/fitnessClasses/`)
            const data2 = await response2.json()
            this.fitnessClasses = data2.fitnessClass;
        },
        methods: {
            async deleteMember(member) {
                if (confirm(`Are you sure you want to delete member '${member.first_name}'?`)) {
                    const response = await fetch(`${baseUrl}${member.api}`, {
                        method: 'DELETE',
                    })
                    if (response.ok)
                        this.members = this.members.filter(m => m.id !== member.id)
                }
            },
            async createMember() {
                const response = await fetch(`${baseUrl}/api/members/`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(this.newMember)
                })
                const newMember = await response.json()
                this.members.push(newMember)
            },
            async deleteFitnessClass(fitnessClass) {
                if (confirm(`Are you sure you want to delete  '${fitnessClass.name}'?`)) {
                    const response = await fetch(`${baseUrl}${fitnessClass.api}`, {
                        method: 'DELETE',
                    })
                    if (response.ok)
                        this.fitnessClasses = this.fitnessClasses.filter(m => m.id !== fitnessClass.id)
                }
            },
            async createFitnessClass() {
                const response = await fetch(`${baseUrl}/api/fitnessClass/`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(this.newFitnessClass)
                })
                const newFitnessClass = await response.json()
                this.fitnessClasses.push(newFitnessClass)
            }

        }
    }
</script>

<style scoped>
</style>

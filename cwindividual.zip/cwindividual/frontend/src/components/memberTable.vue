<template>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">#ID</th>
                <th scope="col">Firstname</th>
                <th scope="col">Surname</th>
                <th scope="col">Email</th>
                <th scope="col">Phone Number</th>
                <th scope="col">Join Date</th>
                <th scope="col">Actions</th>
            </tr>
        </thead>
        <tbody>
            <tr v-for="(member, index) in members">
                <th scope="row">{{ index+1 }}</th>
                <td>
                    {{ member.first_name }}
                </td>
                <td>
                    {{ member.last_name }}
                </td>
                <td>
                    {{ member.email }}
                </td>
                <td>
                    {{ member.phone_number }}
                </td>
                <td>
                    {{ member.join_date }}
                </td>
                <td>
                    <button 
                        class="btn btn-sm btn-primary me-2"
                        @click="editMember"
                    >
                        edit
                    </button>
                    <button 
                        class="btn btn-sm btn-danger"
                        @click="$emit('delete-member', member)"
                    >
                        delete
                    </button>
                </td>
            </tr>
        </tbody>
    </table>
</template>

<script>
    export default {
        emits: ['delete-member'],
        props: {
            members: {
                type: Array,
                required: true
            }
        },
        methods: {
            editMember() {
                alert('Edit member - not implemented');
            }
        }
    }
</script>

<style scoped>
    td, th {
        vertical-align: middle;
    }
</style>
<template>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">#ID</th>
                <th scope="col">Name</th>
                <th scope="col">Description</th>
                <th scope="col">Start Time</th>
                <th scope="col">End Time</th>
                <th scope="col">Instructor</th>
                <th scope="col">Attendees</th>
                <th scope="col">Actions</th>
            </tr>
        </thead>
        <tbody>
            <tr v-for="(fitnessClass, index) in fitnessClasses">
                <th scope="row">{{ index+1 }}</th>
                <td>
                    {{ fitnessClass.name }}
                </td>
                <td>
                    {{ fitnessClass.description }}
                </td>
                <td>
                    {{ fitnessClass.start_time }}
                </td>
                <td>
                    {{ fitnessClass.end_time }}
                </td>
                <td>
                    {{ fitnessClass.instructor }}
                </td>
                <td>
                    <td class ="attendee" v-for="(member,index) in fitnessClass.attendees">
                        {{ member }}
                    </td>
                </td>
                <td>
                    <button 
                        class="btn btn-sm btn-primary me-2"
                        @click="editFitnessClass"
                    >
                        edit
                    </button>
                    <button 
                        class="btn btn-sm btn-danger"
                        @click="$emit('delete-fitnessClass', fitnessClass)"
                    >
                        delete
                    </button>
                </td>
            </tr>
        </tbody>
    </table>
</template>

<script>
    export default {
        emits: ['delete-fitnessClass'],
        props: {
            fitnessClasses: {
                type: Array,
                required: true
            }
        },
        methods: {
            editFitnessClass() {
                alert('Edit Fitness Class - not implemented');
            }
        }
    }
</script>

<style scoped>
    td, th {
        vertical-align: middle;
    }
    .attendee{
        display: table-row;
    }
</style>